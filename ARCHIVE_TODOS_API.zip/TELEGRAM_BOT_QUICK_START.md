# Telegram Bot - Быстрый старт

## Что было реализовано

✅ Telegram бот для уведомлений о задачах:
- Пользователи получают уведомления при назначении новой задачи
- Админы/IT получают уведомления при выполнении/перемещении их задач

## Быстрая настройка

### 1. Создайте бота в Telegram
- Откройте [@BotFather](https://t.me/botfather)
- Отправьте `/newbot` и следуйте инструкциям
- Сохраните токен бота

### 2. Настройте переменные окружения

Добавьте в `.env`:
```env
TELEGRAM_BOT_TOKEN=ваш_токен_бота
TELEGRAM_BOT_ENABLED=true
```

### 3. Получите Chat ID

Запустите скрипт:
```bash
python telegram_bot.py
```

Затем в Telegram:
1. Найдите вашего бота
2. Отправьте `/start`
3. Скопируйте `chat_id` из ответа

### 4. Зарегистрируйтесь в системе

```bash
POST /api/v1/telegram/register
Authorization: Bearer <ваш_токен>
Content-Type: application/json

{
  "telegram_chat_id": "ваш_chat_id",
  "username": "ваш_username"  # опционально
}
```

## Готово! 🎉

Теперь вы будете получать уведомления:
- 📋 Когда вам назначена новая задача
- ✅ Когда ваша задача выполнена (для админов/IT)
- 🔄 Когда ваша задача перемещена (для админов/IT)

## Проверка статуса

```bash
GET /api/v1/telegram/status
Authorization: Bearer <ваш_токен>
```

## Отключение уведомлений

```bash
DELETE /api/v1/telegram/unregister
Authorization: Bearer <ваш_токен>
```

## Подробная документация

См. `TELEGRAM_BOT_SETUP.md` для полной документации.

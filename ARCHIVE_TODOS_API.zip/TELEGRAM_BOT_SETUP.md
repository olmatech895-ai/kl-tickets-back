# Настройка Telegram бота для уведомлений

## Описание

Telegram бот отправляет уведомления пользователям о задачах:
- **Пользователи** получают уведомления, когда им назначена новая задача
- **Админы/IT** получают уведомления, когда их задача выполнена или перемещена

## Шаг 1: Создание Telegram бота

1. Откройте Telegram и найдите бота [@BotFather](https://t.me/botfather)
2. Отправьте команду `/newbot`
3. Следуйте инструкциям и создайте бота
4. Сохраните **Bot Token** (выглядит как `123456789:ABCdefGHIjklMNOpqrsTUVwxyz`)

## Шаг 2: Настройка переменных окружения

Добавьте в файл `.env` или настройки приложения:

```env
TELEGRAM_BOT_TOKEN=ваш_токен_бота
TELEGRAM_BOT_ENABLED=true
```

Или установите через переменные окружения:

```bash
export TELEGRAM_BOT_TOKEN="ваш_токен_бота"
export TELEGRAM_BOT_ENABLED="true"
```

## Шаг 3: Получение Chat ID пользователя

### Вариант 1: Использование скрипта (рекомендуется)

1. Запустите скрипт:
```bash
python telegram_bot.py
```

2. Откройте Telegram и начните диалог с вашим ботом
3. Отправьте команду `/start`
4. Скрипт покажет ваш `chat_id` в консоли
5. Бот также отправит вам сообщение с `chat_id`

### Вариант 2: Через API Telegram

1. Откройте Telegram и начните диалог с вашим ботом
2. Отправьте любое сообщение боту
3. Выполните запрос:
```bash
curl https://api.telegram.org/bot<ВАШ_ТОКЕН>/getUpdates
```

4. Найдите `chat.id` в ответе (это и есть ваш `chat_id`)

## Шаг 4: Регистрация пользователя в системе

После получения `chat_id`, зарегистрируйте пользователя через API:

```bash
POST /api/v1/telegram/register
Authorization: Bearer <ваш_jwt_токен>
Content-Type: application/json

{
  "telegram_chat_id": "123456789",
  "username": "username"  # опционально
}
```

Ответ:
```json
{
  "success": true,
  "message": "Telegram уведомления активированы"
}
```

## Шаг 5: Проверка статуса регистрации

```bash
GET /api/v1/telegram/status
Authorization: Bearer <ваш_jwt_токен>
```

Ответ:
```json
{
  "registered": true,
  "chat_id": "123456789",
  "username": "username"
}
```

## Отключение уведомлений

```bash
DELETE /api/v1/telegram/unregister
Authorization: Bearer <ваш_jwt_токен>
```

## Типы уведомлений

### 1. Назначение задачи пользователю

Когда пользователю назначается новая задача (`assigned_to`), он получает уведомление:

```
📋 Новая задача назначена

Задача: Название задачи
От: Имя создателя

Проверьте вашу доску задач!
```

### 2. Выполнение задачи (для админов/IT)

Когда задача, созданная админом/IT, перемещается в статус "done":

```
✅ Задача выполнена

Задача: Название задачи
Выполнил: Имя исполнителя

Задача перемещена в статус 'Выполнено'
```

### 3. Перемещение задачи (для админов/IT)

Когда задача, созданная админом/IT, перемещается в другой статус:

```
🔄 Задача перемещена

Задача: Название задачи
От: Старый статус
К: Новый статус
Переместил: Имя пользователя
```

## API Endpoints

### POST /api/v1/telegram/register
Регистрация пользователя для получения уведомлений

**Тело запроса:**
```json
{
  "telegram_chat_id": "string",
  "username": "string"  // опционально
}
```

### GET /api/v1/telegram/status
Получить статус регистрации текущего пользователя

### DELETE /api/v1/telegram/unregister
Отключить уведомления для текущего пользователя

## Требования

- Python 3.8+
- `httpx` библиотека (уже добавлена в `requirements.txt`)
- Активный Telegram бот с токеном
- Пользователь должен быть авторизован (JWT токен)

## Устранение неполадок

### Бот не отправляет сообщения

1. Проверьте, что `TELEGRAM_BOT_TOKEN` установлен правильно
2. Убедитесь, что `TELEGRAM_BOT_ENABLED=true`
3. Проверьте, что пользователь начал диалог с ботом в Telegram
4. Проверьте логи приложения на наличие ошибок

### Chat ID не работает

1. Убедитесь, что вы используете правильный `chat_id` (число, не username)
2. Проверьте, что пользователь начал диалог с ботом
3. Попробуйте отправить тестовое сообщение через API Telegram

### Уведомления не приходят

1. Проверьте статус регистрации: `GET /api/v1/telegram/status`
2. Убедитесь, что пользователь зарегистрирован (`registered: true`)
3. Проверьте, что задача действительно назначена пользователю (`assigned_to`)
4. Для уведомлений о выполнении/перемещении проверьте, что создатель задачи - админ/IT

## Примеры использования

### JavaScript/TypeScript

```javascript
// Регистрация
const registerTelegram = async (chatId, username) => {
  const response = await fetch('/api/v1/telegram/register', {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${token}`,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      telegram_chat_id: chatId,
      username: username
    })
  });
  return response.json();
};

// Проверка статуса
const getTelegramStatus = async () => {
  const response = await fetch('/api/v1/telegram/status', {
    headers: {
      'Authorization': `Bearer ${token}`
    }
  });
  return response.json();
};
```

### Python

```python
import requests

# Регистрация
def register_telegram(token, chat_id, username=None):
    url = "http://localhost:8000/api/v1/telegram/register"
    headers = {
        "Authorization": f"Bearer {token}",
        "Content-Type": "application/json"
    }
    data = {
        "telegram_chat_id": chat_id,
        "username": username
    }
    response = requests.post(url, json=data, headers=headers)
    return response.json()
```

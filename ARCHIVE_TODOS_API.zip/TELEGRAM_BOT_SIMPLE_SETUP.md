# Простая настройка Telegram бота

## Как это работает

1. **Пользователь в веб-приложении** нажимает "Подключить Telegram"
2. **Backend генерирует уникальную ссылку** типа `https://t.me/your_bot?start=TOKEN`
3. **Пользователь переходит по ссылке** в Telegram
4. **Нажимает кнопку Start**
5. **Бот автоматически регистрирует пользователя** и начинает отправлять уведомления

## Быстрая настройка

### 1. Настройте переменные окружения

В файле `.env`:

```env
TELEGRAM_BOT_TOKEN=8053249668:AAG1gqpd1HdlwT3TiefbDWnbECKx6sF-voM
TELEGRAM_BOT_ENABLED=true
BACKEND_URL=http://localhost:8000
```

**Важно:** Если ваш backend работает на другом адресе (например, на сервере), измените `BACKEND_URL`:
```env
BACKEND_URL=https://your-domain.com
```

### 2. Запустите Telegram бота

В отдельном терминале запустите:

```bash
python telegram_bot.py
```

Бот будет работать постоянно и обрабатывать команды `/start` от пользователей.

### 3. Используйте API на фронтенде

#### Получить ссылку для пользователя:

```javascript
// GET или POST /api/v1/telegram/link
const response = await fetch('/api/v1/telegram/link', {
  method: 'POST',
  headers: {
    'Authorization': `Bearer ${userToken}`,
    'Content-Type': 'application/json'
  }
});

const data = await response.json();
// data.bot_link - это ссылка типа "https://t.me/your_bot?start=TOKEN"
```

#### Показать пользователю кнопку:

```javascript
// После получения ссылки
const botLink = data.bot_link;

// Создать кнопку или ссылку
<button onClick={() => window.open(botLink, '_blank')}>
  Подключить Telegram
</button>
```

#### Проверить статус регистрации:

```javascript
const response = await fetch('/api/v1/telegram/status', {
  headers: {
    'Authorization': `Bearer ${userToken}`
  }
});

const status = await response.json();
if (status.registered) {
  console.log('Telegram подключен!');
} else {
  console.log('Telegram не подключен');
}
```

## Пример полного потока

### На фронтенде:

```javascript
async function connectTelegram() {
  try {
    // 1. Получить ссылку
    const linkResponse = await fetch('/api/v1/telegram/link', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json'
      }
    });
    
    const linkData = await linkResponse.json();
    
    if (linkData.success) {
      // 2. Открыть ссылку в Telegram
      window.open(linkData.bot_link, '_blank');
      
      // 3. Показать инструкцию
      alert('Перейдите в Telegram и нажмите Start для активации');
      
      // 4. Проверить статус через несколько секунд
      setTimeout(async () => {
        const statusResponse = await fetch('/api/v1/telegram/status', {
          headers: { 'Authorization': `Bearer ${token}` }
        });
        const status = await statusResponse.json();
        
        if (status.registered) {
          alert('✅ Telegram успешно подключен!');
        }
      }, 5000);
    }
  } catch (error) {
    console.error('Ошибка подключения Telegram:', error);
  }
}
```

## API Endpoints

### POST /api/v1/telegram/link
Получить ссылку для подключения Telegram

**Требует:** Авторизации (JWT токен)

**Ответ:**
```json
{
  "success": true,
  "bot_link": "https://t.me/your_bot?start=TOKEN",
  "message": "Перейдите по ссылке и нажмите Start для активации уведомлений"
}
```

### GET /api/v1/telegram/link
То же самое, но GET метод

### GET /api/v1/telegram/status
Проверить статус регистрации

**Требует:** Авторизации (JWT токен)

**Ответ:**
```json
{
  "registered": true,
  "chat_id": "123456789",
  "username": "username"
}
```
или
```json
{
  "registered": false
}
```

### DELETE /api/v1/telegram/unregister
Отключить уведомления

**Требует:** Авторизации (JWT токен)

## Важные моменты

1. **Бот должен работать постоянно** - запустите `python telegram_bot.py` и оставьте его работать
2. **BACKEND_URL должен быть доступен** - если бот на сервере, а backend локально, это не сработает
3. **Токены действительны 1 час** - если пользователь не успел нажать Start, нужно получить новую ссылку
4. **Один пользователь = одна регистрация** - повторная регистрация обновит существующую

## Уведомления

После регистрации пользователь автоматически начнет получать:

- 📋 **Новые задачи** - когда ему назначают задачу
- ✅ **Выполнение задач** (для админов/IT) - когда их задача выполнена
- 🔄 **Перемещение задач** (для админов/IT) - когда их задача перемещена в другой статус

## Устранение неполадок

### Бот не отвечает

1. Проверьте, что `telegram_bot.py` запущен
2. Проверьте `TELEGRAM_BOT_TOKEN` в `.env`
3. Проверьте логи бота в консоли

### Регистрация не работает

1. Проверьте `BACKEND_URL` - он должен быть доступен из того места, где работает бот
2. Проверьте, что backend запущен
3. Проверьте логи backend на наличие ошибок

### Пользователь не получает уведомления

1. Проверьте статус: `GET /api/v1/telegram/status`
2. Убедитесь, что `registered: true`
3. Проверьте, что задача действительно назначена пользователю (`assigned_to`)

# Application Layer - Use Cases and DTOs


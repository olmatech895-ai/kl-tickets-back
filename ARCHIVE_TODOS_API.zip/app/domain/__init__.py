# Domain Layer - Бизнес-логика и сущности


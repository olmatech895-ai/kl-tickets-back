#!/bin/bash
echo "Starting FastAPI server..."
python run.py

